import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Pgadmin3 {
   public static void main(String args[]) {
      Connection c = null;
      Statement stmt = null;
      try {
         Class.forName("org.postgresql.Driver");
         c = DriverManager
            .getConnection("jdbc:postgresql://localhost:5432/postgres",
            "postgres", "manideep@1");
         c.setAutoCommit(false);
         System.out.println("Opened database successfully");

         stmt = c.createStatement();
         String sql = "INSERT INTO PATIENT (PATIENT_ID,PATIENT_NAME,PATIENT_BG,PATIENT_GEN) "
               + "VALUES (1, 'Mike', 'B+', 'M' );";
        stmt.executeUpdate(sql);

         sql = "INSERT INTO PATIENT (PATIENT_ID,PATIENT_NAME,PATIENT_BG,PATIENT_GEN) "
               + "VALUES (2, 'Alien', 'AB+', 'M' );";
         stmt.executeUpdate(sql);

         sql = "INSERT INTO PATIENT (PATIENT_ID,PATIENT_NAME,PATIENT_BG,PATIENT_GEN) "
               + "VALUES (3, 'Ted', 'O+', 'F' );";
         stmt.executeUpdate(sql);

         sql = "INSERT INTO PATIENT (PATIENT_ID,PATIENT_NAME,PATIENT_BG,PATIENT_GEN) "
               + "VALUES (4, 'Mars', 'O-', 'M' );";
         stmt.executeUpdate(sql);
         
        sql = "INSERT INTO PATIENT (PATIENT_ID,PATIENT_NAME,PATIENT_BG,PATIENT_GEN) "
               + "VALUES (5, 'Jimmy', 'A-', 'M' );";
         stmt.executeUpdate(sql);

         stmt.close();
         c.commit();
         c.close();
      } catch (Exception e) {
         System.err.println( e.getClass().getName()+": "+ e.getMessage() );
         System.exit(0);
      }
      System.out.println("Records created successfully");
   }
}