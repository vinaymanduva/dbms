import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Transaction1 {
   public static void main(String args[]) {
      Connection c = null;
      Statement stmt = null;
      try {
         Class.forName("org.postgresql.Driver");
         c = DriverManager
            .getConnection("jdbc:postgresql://localhost:5432/postgres",
            "postgres", "manideep@1");
         c.setAutoCommit(false);
         System.out.println("Opened database successfully");

         stmt = c.createStatement();
         String sql = "INSERT INTO TRANSACTION (PATIENT_ID,PATIENT_NAME,CONTACT_NO,BILL_NO,ACC_CHARGES,DATE,DOC_FEE,MED_FEE,TOT_AM) "
              + "VALUES (1,'Kid',9123456780,1210,2000,'20-JAN-2016',500,700,3200);";
        stmt.executeUpdate(sql);

         sql =  "INSERT INTO TRANSACTION (PATIENT_ID,PATIENT_NAME,CONTACT_NO,BILL_NO,ACC_CHARGES,DATE,DOC_FEE,MED_FEE,TOT_AM) "
              + "VALUES (2,'Alien',9123456781,1211,1000,'20-JUL-2016',500,200,1700);";
         stmt.executeUpdate(sql);

         sql =  "INSERT INTO TRANSACTION (PATIENT_ID,PATIENT_NAME,CONTACT_NO,BILL_NO,ACC_CHARGES,DATE,DOC_FEE,MED_FEE,TOT_AM) "
              + "VALUES (3,'Ted',9123456782,1212,5000,'12-OCT-2016',500,300,5800);";
         stmt.executeUpdate(sql);

         sql = "INSERT INTO TRANSACTION (PATIENT_ID,PATIENT_NAME,CONTACT_NO,BILL_NO,ACC_CHARGES,DATE,DOC_FEE,MED_FEE,TOT_AM) "
              + "VALUES (4,'King',9123456783,1213,500,'24-MAR-2016',500,800,1800);";
         stmt.executeUpdate(sql);
         
        sql =  "INSERT INTO TRANSACTION (PATIENT_ID,PATIENT_NAME,CONTACT_NO,BILL_NO,ACC_CHARGES,DATE,DOC_FEE,MED_FEE,TOT_AM) "
              + "VALUES (5,'Jimmy',9123456784,1214,1500,'2-FEB-2016',500,900,2900);";
         stmt.executeUpdate(sql);

         stmt.close();
         c.commit();
         c.close();
      } catch (Exception e) {
         System.err.println( e.getClass().getName()+": "+ e.getMessage() );
         System.exit(0);
      }
      System.out.println("Records created successfully");
   }
}