import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class BloodBottle1 {
   public static void main(String args[]) {
      Connection c = null;
      Statement stmt = null;
      try {
         Class.forName("org.postgresql.Driver");
         c = DriverManager
            .getConnection("jdbc:postgresql://localhost:5432/postgres",
            "postgres", "manideep@1");
         c.setAutoCommit(false);
         System.out.println("Opened database successfully");

         stmt = c.createStatement();
         String sql = "INSERT INTO BLOODBOTTLE (BLOODBOTTLE_ID,DONOR_NAME,BLOOD_TYPE,DONOR_NO) "
              + "VALUES (1, 'THARA','AB-',944567890);";
        stmt.executeUpdate(sql);

         sql = "INSERT INTO BLOODBOTTLE (BLOODBOTTLE_ID,DONOR_NAME,BLOOD_TYPE,DONOR_NO) "
              + "VALUES (2, 'ASHA','O+',944567894);";
         stmt.executeUpdate(sql);

         sql  = "INSERT INTO BLOODBOTTLE (BLOODBOTTLE_ID,DONOR_NAME,BLOOD_TYPE,DONOR_NO) "
              + "VALUES (3, 'ASHOK','AB+',944567892);";
         stmt.executeUpdate(sql);

         sql =  "INSERT INTO BLOODBOTTLE (BLOODBOTTLE_ID,DONOR_NAME,BLOOD_TYPE,DONOR_NO) "
              + "VALUES (4, 'KP','B+',944567891);";
         stmt.executeUpdate(sql);
         
        sql  = "INSERT INTO BLOODBOTTLE (BLOODBOTTLE_ID,DONOR_NAME,BLOOD_TYPE,DONOR_NO) "
              + "VALUES (5, 'JAYASREE','A-',944567893);";
         stmt.executeUpdate(sql);

         stmt.close();
         c.commit();
         c.close();
      } catch (Exception e) {
         System.err.println( e.getClass().getName()+": "+ e.getMessage() );
         System.exit(0);
      }
      System.out.println("Records created successfully");
   }
}