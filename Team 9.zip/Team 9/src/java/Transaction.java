import java.sql.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class Transaction {
   public static void main( String args[] )
     {
       Connection c = null;
       Statement stmt = null;
       try {
         Class.forName("org.postgresql.Driver");
         c = DriverManager
            .getConnection("jdbc:postgresql://localhost:5432/postgres",
            "postgres", "manideep@1");
         System.out.println("Opened database successfully");

         stmt = c.createStatement();
         String sql = "CREATE TABLE TRANSACTION " +
                      "(PATIENT_ID INT NOT NULL," +
                      "PATIENT_NAME TEXT NOT NULL, " +
                      "CONTACT_NO BIGINT NOT NULL, " +
                      " BILL_NO BIGINT NOT NULL, " +
                      " ACC_CHARGES BIGINT NOT NULL, " +
                      " DATE DATE NOT NULL, " +
                      " DOC_FEE BIGINT NOT NULL, " +
                      " MED_FEE BIGINT NOT NULL, " +
                      " TOT_AM BIGINT NOT NULL) " ;
         stmt.executeUpdate(sql);
         stmt.close();
         c.close();
       } catch ( Exception e ) {
         System.err.println( e.getClass().getName()+": "+ e.getMessage() );
         System.exit(0);
       }
       System.out.println("Table created successfully");
     }
}