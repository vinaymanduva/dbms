import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.*;
import java.util.Enumeration;

public class pgtest
{
	public static void main (String[] args)

	{
		System.out.println("Testing Postgresql");
		try
		{
			Class.forName("org.postgresql.Driver");
			System.out.println("Registered POSTGRESQL");
		}
		catch (ClassNotFoundException e)
		{
			System.out.println("PG jdbc not found");
		}


		// list jdbc drivers registered
		try {
	        Enumeration<Driver> drivers = DriverManager.getDrivers();
	        while (drivers.hasMoreElements()) {
	            Driver nextElement = drivers.nextElement();
				System.out.println("JDBC Driver=" + nextElement);

	        }
    	} catch (Exception e) {
    	//************************************************************


    	}

		Connection con = null;

		try
		{
			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "manideep@1");

		}
		
		catch(Exception e)
		{
			System.out.println("Unable to connect to server");
			System.out.println(e.getMessage());
			return;
		}

		Statement st = null;

		try
		{

			st = con.createStatement();
		}
		catch (Exception e)
		{

		}


		try
		{
			ResultSet rs = st.executeQuery("select * from doctor");
			while(rs.next())
			{
				System.out.print(rs.getString(1));
				System.out.print(" - ");
				System.out.print(rs.getString(2));
				System.out.println();
			}

		}
		catch (Exception e)
		{

		}


		System.out.println("End");
	}

}