import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Practitioner1 {
   public static void main(String args[]) {
      Connection c = null;
      Statement stmt = null;
      try {
         Class.forName("org.postgresql.Driver");
         c = DriverManager
            .getConnection("jdbc:postgresql://localhost:5432/postgres",
            "postgres", "manideep@1");
         c.setAutoCommit(false);
         System.out.println("Opened database successfully");

         stmt = c.createStatement();
         String sql = "INSERT INTO PRACTITIONER (PRA_ID,PRA_NAME,SALARY,DOCTOR_ID) "
              + "VALUES (1, 'ARJUN', 20000.00, 3 );";
        stmt.executeUpdate(sql);

         sql = "INSERT INTO PRACTITIONER (PRA_ID,PRA_NAME,SALARY,DOCTOR_ID) "
              + "VALUES (2, 'ARUN', 10000.00, 4 );";
         stmt.executeUpdate(sql);

         sql  = "INSERT INTO PRACTITIONER (PRA_ID,PRA_NAME,SALARY,DOCTOR_ID) "
              + "VALUES (3, 'SUMA', 20000.00, 3 );";
         stmt.executeUpdate(sql);

         sql =  "INSERT INTO PRACTITIONER (PRA_ID,PRA_NAME,SALARY,DOCTOR_ID) "
              + "VALUES (4, 'NAMAN', 30000.00, 5 );";
         stmt.executeUpdate(sql);
         
        sql  = "INSERT INTO PRACTITIONER (PRA_ID,PRA_NAME,SALARY,DOCTOR_ID) "
              + "VALUES (5, 'MONA', 5000.00, 1 );";
         stmt.executeUpdate(sql);

         stmt.close();
         c.commit();
         c.close();
      } catch (Exception e) {
         System.err.println( e.getClass().getName()+": "+ e.getMessage() );
         System.exit(0);
      }
      System.out.println("Records created successfully");
   }
}