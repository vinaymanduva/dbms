import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Pgadmin11 {
   public static void main(String args[]) {
      Connection c = null;
      Statement stmt = null;
      try {
         Class.forName("org.postgresql.Driver");
         c = DriverManager
            .getConnection("jdbc:postgresql://localhost:5432/postgres",
            "postgres", "manideep@1");
         c.setAutoCommit(false);
         System.out.println("Opened database successfully");

         stmt = c.createStatement();
         String sql = "INSERT INTO DEPARTMENT (DEPT_ID,DEP_NAME,DEPT_DOC,DEPT_HEAD,PHN_NO) "
              + "VALUES (1, 'CARDIOLOGY','Manikanta','WILSON', 888662427 );";
        stmt.executeUpdate(sql);

         sql = "INSERT INTO DEPARTMENT (DEPT_ID,DEP_NAME,DEPT_DOC,DEPT_HEAD,PHN_NO) "
              + "VALUES (2, 'PSCYCHRIATRY','JOHN','AKASH', 888662428 );";
         stmt.executeUpdate(sql);

         sql = "INSERT INTO DEPARTMENT (DEPT_ID,DEP_NAME,DEPT_DOC,DEPT_HEAD,PHN_NO) "
              + "VALUES (3, 'CARDIOLOGY','Manideep','WILSON', 888662427 );";
         stmt.executeUpdate(sql);

         sql = "INSERT INTO DEPARTMENT (DEPT_ID,DEP_NAME,DEPT_DOC,DEPT_HEAD,PHN_NO) "
              + "VALUES (4, 'SURGERY','Vinay','Prasanth', 888662429 );";
         stmt.executeUpdate(sql);
         
        sql = "INSERT INTO DEPARTMENT (DEPT_ID,DEP_NAME,DEPT_DOC,DEPT_HEAD,PHN_NO) "
              + "VALUES (5, 'ANESTHESIA','VISWA','AKHIL', 888662420 );";
         stmt.executeUpdate(sql);

         stmt.close();
         c.commit();
         c.close();
      } catch (Exception e) {
         System.err.println( e.getClass().getName()+": "+ e.getMessage() );
         System.exit(0);
      }
      System.out.println("Records created successfully");
   }
}