import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Pgadmin7 {
   public static void main(String args[]) {
      Connection c = null;
      Statement stmt = null;
      try {
         Class.forName("org.postgresql.Driver");
         c = DriverManager
            .getConnection("jdbc:postgresql://localhost:5432/postgres",
            "postgres", "manideep@1");
         c.setAutoCommit(false);
         System.out.println("Opened database successfully");

         stmt = c.createStatement();
         String sql = "INSERT INTO MEDICINE (MED_ID,MED_NAME,MANUFACTURER_NAME,MED_TYPE,EXP_DATE) "
              + "VALUES (1, 'CITROGEN','Manikanta','TABLET', '30-OCT-2020' );";
        stmt.executeUpdate(sql);

         sql = "INSERT INTO MEDICINE (MED_ID,MED_NAME,MANUFACTURER_NAME,MED_TYPE,EXP_DATE) "
              + "VALUES (2, 'CROCIN','Manideep','TABLET', '28-NOV-2020' );";
         stmt.executeUpdate(sql);

         sql = "INSERT INTO MEDICINE (MED_ID,MED_NAME,MANUFACTURER_NAME,MED_TYPE,EXP_DATE) "
              + "VALUES (3, 'BENADRYL','Vinay','SYRUP', '30-OCT-2019' );";
         stmt.executeUpdate(sql);

         sql = "INSERT INTO MEDICINE (MED_ID,MED_NAME,MANUFACTURER_NAME,MED_TYPE,EXP_DATE) "
              + "VALUES (4, 'COLDACT','Gokul','TABLET', '30-JUN-2024' );";
         stmt.executeUpdate(sql);
         
        sql = "INSERT INTO MEDICINE (MED_ID,MED_NAME,MANUFACTURER_NAME,MED_TYPE,EXP_DATE) "
              + "VALUES (5, 'WIKORYL','Aseesh','CAPSULES', '30-SEP-2018' );";
         stmt.executeUpdate(sql);

         stmt.close();
         c.commit();
         c.close();
      } catch (Exception e) {
         System.err.println( e.getClass().getName()+": "+ e.getMessage() );
         System.exit(0);
      }
      System.out.println("Records created successfully");
   }
}