import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Doctor2 {
   public static void main(String args[]) {
      Connection c = null;
      Statement stmt = null;
      try {
         Class.forName("org.postgresql.Driver");
         c = DriverManager
            .getConnection("jdbc:postgresql://localhost:5432/postgres",
            "postgres", "manideep@1");
         c.setAutoCommit(false);
         System.out.println("Opened database successfully");

         stmt = c.createStatement();
         String sql = "INSERT INTO DOCTOR (DOCTOR_ID,DOCTOR_NAME,SALARY,EMAIL_ID,DEP_NAME) "
              + "VALUES (1, 'Paul', 20000.00, 'rmmanideep727@gmail.com', 'ANESTHESIA' );";
        stmt.executeUpdate(sql);

         sql = "INSERT INTO DOCTOR (DOCTOR_ID,DOCTOR_NAME,SALARY,EMAIL_ID,DEP_NAME) "
               + "VALUES (2, 'Allen', 15000.00,'Texas', 'CARDIOLOGY' );";
         stmt.executeUpdate(sql);

         sql = "INSERT INTO DOCTOR (DOCTOR_ID,DOCTOR_NAME,SALARY,EMAIL_ID,DEP_NAME) "
               + "VALUES (3, 'Teddy', 20000.00,'Norway','GYNICOLOGY' );";
         stmt.executeUpdate(sql);

         sql = "INSERT INTO DOCTOR(DOCTOR_ID,DOCTOR_NAME,SALARY,EMAIL_ID,DEP_NAME) "
               + "VALUES (4, 'Mark', 65000.00, 'America', 'SURGERY' );";
         stmt.executeUpdate(sql);
         
        sql = "INSERT INTO DOCTOR(DOCTOR_ID,DOCTOR_NAME,SALARY,EMAIL_ID,DEP_NAME) "
               + "VALUES (5, 'Nick', 6500.00, 'Australia', 'GENERAL PHYSICIAN' );";
         stmt.executeUpdate(sql);

         stmt.close();
         c.commit();
         c.close();
      } catch (Exception e) {
         System.err.println( e.getClass().getName()+": "+ e.getMessage() );
         System.exit(0);
      }
      System.out.println("Records created successfully");
   }
}